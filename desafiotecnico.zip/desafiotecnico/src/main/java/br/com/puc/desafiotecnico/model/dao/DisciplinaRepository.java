package br.com.puc.desafiotecnico.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.puc.desafiotecnico.model.entity.Disciplina;

public interface DisciplinaRepository extends JpaRepository<Disciplina, String>{
	
	
	public Disciplina findOneBynome(String nome);

}
