package br.com.puc.desafiotecnico.service;

import java.util.List;

import br.com.puc.desafiotecnico.model.dto.AlunoDto;
import br.com.puc.desafiotecnico.model.dto.RequestAlterarPeso;
import br.com.puc.desafiotecnico.model.dto.ResponseMedia;

public interface DesafioTecnicoService {
	
	public void cadastrarNotas(List<AlunoDto> list);

	public void alterarPesoNotas(RequestAlterarPeso notas);
	
	public List<ResponseMedia> buscarNotas();

}
