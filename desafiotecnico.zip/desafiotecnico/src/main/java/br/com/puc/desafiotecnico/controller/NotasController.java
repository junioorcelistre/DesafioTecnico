package br.com.puc.desafiotecnico.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.puc.desafiotecnico.model.dto.RequestAlterarPeso;
import br.com.puc.desafiotecnico.model.dto.RequestCadastrar;
import br.com.puc.desafiotecnico.model.dto.ResponseMedia;
import br.com.puc.desafiotecnico.service.DesafioTecnicoService;

@RestController
public class NotasController {

	@Autowired
	DesafioTecnicoService desafioTecnicoService;

	@PostMapping(value = "/cadastrar/notas")
	void cadastrarNotas(@RequestBody RequestCadastrar request) {
		desafioTecnicoService.cadastrarNotas(request.getAlunos());
	}

	@GetMapping(value = "/buscar/notas")
	@ResponseBody List<ResponseMedia> buscarNotas() {
		return desafioTecnicoService.buscarNotas();
	}
	
	@PutMapping(value = "/alterar/peso/notas")
	void alterarPeso(@RequestBody RequestAlterarPeso request) {
		desafioTecnicoService.alterarPesoNotas(request);
	}
	
}
