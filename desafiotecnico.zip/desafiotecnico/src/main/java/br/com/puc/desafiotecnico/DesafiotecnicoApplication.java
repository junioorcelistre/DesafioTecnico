package br.com.puc.desafiotecnico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafiotecnicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafiotecnicoApplication.class, args);
	}

}
