package br.com.puc.desafiotecnico.model.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.puc.desafiotecnico.model.entity.Prova;

public interface ProvaRepository extends JpaRepository<Prova, String> {
	
	
	@Query(value = "SELECT SUM((p.NOTA * p.PESO))/d.quantidade_avaliacoes as media, a.nome as aluno, d.nome as disciplina"
	+"\nFROM PROVA  as p"
	+"\nJOIN Aluno as a"
	+"\nON p.aluno_id = a.id"
	+"\nJOIN disciplina as d" 
	+"\non p.disciplina_id = d.id"
	+"\nGroup by p.aluno_id, p.disciplina_id",
	nativeQuery = true)
	public List<?> findMediaGroupbyAlunoDisciplina();
	
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value = "update PROVA SET peso = :peso where nome =:nome and disciplina_id =:disciplina_id", nativeQuery = true)
	public void setPesoNotas(@Param("peso") int peso, @Param("nome") String nome, @Param("disciplina_id") int disciplina_id);
	

}
