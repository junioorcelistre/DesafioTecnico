package br.com.puc.desafiotecnico.service.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.puc.desafiotecnico.model.dao.AlunoRepository;
import br.com.puc.desafiotecnico.model.dao.DisciplinaRepository;
import br.com.puc.desafiotecnico.model.dao.ProvaRepository;
import br.com.puc.desafiotecnico.model.dto.AlunoDto;
import br.com.puc.desafiotecnico.model.dto.DisciplinaDto;
import br.com.puc.desafiotecnico.model.dto.RequestAlterarPeso;
import br.com.puc.desafiotecnico.model.dto.ResponseMedia;
import br.com.puc.desafiotecnico.model.entity.Aluno;
import br.com.puc.desafiotecnico.model.entity.Disciplina;
import br.com.puc.desafiotecnico.model.entity.Prova;
import br.com.puc.desafiotecnico.service.DesafioTecnicoService;

@Service("desafioTecnicoService")
public class DesafioTecnicoServiceImpl implements DesafioTecnicoService {

	@Autowired
	AlunoRepository alunoRepository;

	@Autowired
	DisciplinaRepository disciplinaRepository;

	@Autowired
	ProvaRepository provaRespository;
	
	
	public List<ResponseMedia> buscarNotas() {
		List<ResponseMedia> response = new ArrayList<ResponseMedia>();
		for(Object obj : provaRespository.findMediaGroupbyAlunoDisciplina()) {
			Object[] array = (Object[]) obj;
			response.add(ResponseMedia.builder().nota((double) array[0]).aluno(array[1].toString()).disciplina(array[2].toString()).build());
		}
		return response;
	}
	
	public void alterarPesoNotas(RequestAlterarPeso notas) {
		Disciplina disciplina = disciplinaRepository.findOneBynome(notas.getDisciplina());
		provaRespository.setPesoNotas(notas.getPeso(), notas.getProva(), disciplina.getId());
	}
	
	public void cadastrarNotas(List<AlunoDto> alunos) {
		for (AlunoDto aluno : alunos) {
			Aluno alunoEntity = Aluno.builder()
					.id(aluno.getId())
					.nome(aluno.getNome())
					.build();
			alunoRepository.save(alunoEntity);
			for (DisciplinaDto disciplina : aluno.getDisciplinas()) {
				Disciplina disciplinaEntity = Disciplina.builder()
						.id(disciplina.getId())
						.nome(disciplina.getNome())
						.quantidade_avaliacoes(disciplina.getNotas().size())
						.build();
				disciplinaRepository.save(disciplinaEntity);
				int prova = 1;
				for (LinkedHashMap<String, Object> nota : disciplina.getNotas()) {
					String nome = "Prova"+prova;
					Prova provaEntity = Prova.builder()
							.id((int) nota.get("id"))
							.nome(nome)
							.nota((double) nota.get(nome))
							.peso(1)
							.aluno_id(alunoEntity.getId())
							.disciplina_id(disciplinaEntity.getId()).build();
					provaRespository.save(provaEntity);
					prova++;
				}
			}
		}
	}

}
