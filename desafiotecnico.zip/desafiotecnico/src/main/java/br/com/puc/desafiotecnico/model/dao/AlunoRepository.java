package br.com.puc.desafiotecnico.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.puc.desafiotecnico.model.entity.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, String> {

}
