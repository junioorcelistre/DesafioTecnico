package br.com.puc.desafiotecnico.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestAlterarPeso {
	
	String prova;
	String disciplina;
	int peso;

}
