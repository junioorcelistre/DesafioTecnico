package br.com.puc.desafiotecnico.model.dto;

import java.util.LinkedHashMap;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DisciplinaDto {
	
	int id;
	String nome;
	List<LinkedHashMap<String, Object>> notas;
}
