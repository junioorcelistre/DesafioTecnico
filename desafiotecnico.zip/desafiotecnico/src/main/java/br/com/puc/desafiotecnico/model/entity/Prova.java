package br.com.puc.desafiotecnico.model.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Prova {
	
	@Id
	int id;
	
	String nome;
	
	double nota;
	
	int peso;
	
	int aluno_id;
	
	int disciplina_id;
}
